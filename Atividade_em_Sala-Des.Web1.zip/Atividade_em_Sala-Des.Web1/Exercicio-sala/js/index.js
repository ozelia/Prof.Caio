var area = document.querySelector("input");
var botao = document.querySelector("button");
var lista = document.querySelector(".lista");




botao.addEventListener("click",function(){
    var citacao = area.value;
    var li = document.createElement("li");
    li.textContent = citacao;
    lista.appendChild(li);
});
var n = 2;

for(var i=1;i<=10;i++){
    console.log(n+' x '+i+' ='+n*i);
}